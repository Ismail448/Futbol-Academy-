package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.entity.Preguntas;
import com.example.registrationlogindemo.modelo.Futbol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface RepositorioPreguntas extends JpaRepository<Preguntas, Long> {
    public ArrayList<Preguntas> findAll();
    public Preguntas findById(long id);
    public Preguntas save(Preguntas preguntas);

    public ArrayList<Preguntas> findByPreguntas(String preguntas);

}
