package com.example.registrationlogindemo.entity;


import jakarta.persistence.*;
import lombok.Data;

import java.util.List;
@Data
@Entity
@Table(name = "preguntas")
public class Preguntas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "preguntas")
    private String preguntas;

    @ElementCollection
    @CollectionTable(name = "respuestas", joinColumns = @JoinColumn(name = "pregunta_id"))
    @Column(name = "respuesta")
    private List<String> respuestas;

    @Column(name = "respuesta_correcta")
    private String respuestaCorrecta;

}

