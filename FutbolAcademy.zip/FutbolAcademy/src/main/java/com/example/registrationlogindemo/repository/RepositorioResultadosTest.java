package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.entity.ResultadosTest;
import com.example.registrationlogindemo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface RepositorioResultadosTest extends JpaRepository<ResultadosTest, Long> {
    public ArrayList<ResultadosTest> findAll();
    public ResultadosTest findById(long id);
    public ResultadosTest save(ResultadosTest resultadosTest);

    public ArrayList<ResultadosTest> findByUser(User user);
}
