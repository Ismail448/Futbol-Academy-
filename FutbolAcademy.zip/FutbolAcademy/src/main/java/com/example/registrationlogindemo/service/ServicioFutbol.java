package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.modelo.Futbol;
import com.example.registrationlogindemo.repository.RepositorioFutbol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServicioFutbol {

    @Autowired
    RepositorioFutbol repo;

    public ArrayList<Futbol> findAll() {
        return repo.findAll();
    }

    public Futbol findById(long id){
        return repo.findById(id);
    }

    public Futbol save(Futbol futbol){
        return repo.save(futbol);
    }

    public ArrayList<Futbol> findByTitulo(String titulo){
        return repo.findByTitulo(titulo);
    }

    public void deleteById(long id) {
        repo.deleteById(id);
    }
}
