package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.entity.Preguntas;
import com.example.registrationlogindemo.modelo.Comentario;
import com.example.registrationlogindemo.modelo.Futbol;
import com.example.registrationlogindemo.repository.RepositorioPreguntas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
public class ServicioPreguntas {
    @Autowired
    RepositorioPreguntas repositorioPreguntas;

    public ArrayList<Preguntas> findAll(){
        return repositorioPreguntas.findAll();
    }

    public Preguntas findById(long id){
        return repositorioPreguntas.findById(id);
    }

    public ArrayList<Preguntas> findByTutorial(Preguntas preguntas){
        return repositorioPreguntas.findByPreguntas(String.valueOf(preguntas));
    }

    public Preguntas save(Preguntas preguntas){
        return repositorioPreguntas.save(preguntas);
    }

    public void delete(Preguntas preguntas){
        repositorioPreguntas.delete(preguntas);
    }

    public List<Preguntas> findRandomPreguntas(int quantity) {
        List<Preguntas> allQuestions = repositorioPreguntas.findAll();
        List<Preguntas> randomQuestions = new ArrayList<>();
        Random random = new Random();

        // Verificar si hay suficientes preguntas en la base de datos
        if (allQuestions.size() <= quantity) {
            return allQuestions;
        }

        while (randomQuestions.size() < quantity) {
            int randomIndex = random.nextInt(allQuestions.size());
            randomQuestions.add(allQuestions.get(randomIndex));
            allQuestions.remove(randomIndex);
        }

        return randomQuestions;
    }
}
