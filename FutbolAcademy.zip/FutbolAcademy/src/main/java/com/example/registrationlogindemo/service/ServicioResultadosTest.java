package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.entity.Preguntas;
import com.example.registrationlogindemo.entity.ResultadosTest;
import com.example.registrationlogindemo.entity.User;
import com.example.registrationlogindemo.modelo.Futbol;
import com.example.registrationlogindemo.repository.RepositorioResultadosTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServicioResultadosTest {
    @Autowired
    RepositorioResultadosTest repositorioResultadosTest;

    public ArrayList<ResultadosTest> findAll() {
        return repositorioResultadosTest.findAll();
    }

    public ResultadosTest findById(long id){
        return repositorioResultadosTest.findById(id);
    }

    public ResultadosTest save(ResultadosTest resultadosTest){
        return repositorioResultadosTest.save(resultadosTest);
    }
    public ArrayList<ResultadosTest> findByUser(User user) { return repositorioResultadosTest.findByUser(user);}
}
