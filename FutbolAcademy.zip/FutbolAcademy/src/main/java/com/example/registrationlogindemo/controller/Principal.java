package com.example.registrationlogindemo.controller;

import com.example.registrationlogindemo.entity.Mensaje;
import com.example.registrationlogindemo.entity.Preguntas;
import com.example.registrationlogindemo.entity.ResultadosTest;
import com.example.registrationlogindemo.entity.User;
import com.example.registrationlogindemo.modelo.Comentario;
import com.example.registrationlogindemo.modelo.Futbol;
import com.example.registrationlogindemo.repository.RepositorioPreguntas;
import com.example.registrationlogindemo.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.aspectj.weaver.patterns.TypePatternQuestions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Controller
public class Principal {
    @Autowired
    ServicioMensajes servicioMensajes;
    @Autowired
    UserService servicioUsuarios;
    @Autowired
    ServicioFutbol servicioFutbol;
    @Autowired
    ServicioComentarios servicioComentarios;
    @Autowired
    ServicioPreguntas servicioPreguntas;
    @Autowired
    ServicioResultadosTest servicioResultadosTest;


    @GetMapping("/")
    public String principal(Model model) {
        //Recupero la lista de usuarios y la mando a la plantilla para decir quién soy
        //model.addAttribute("lista", servicioUsuarios.findAll());
        //return "tutoriales";

        ArrayList<Futbol> tutoriales = servicioFutbol.findAll();
        model.addAttribute("tutoriales", tutoriales);
        return "tutoriales";
    }

    @GetMapping("/futbol/{id}")
    public String futbol(@PathVariable long id, Model model) {
        Futbol futbol = servicioFutbol.findById(id);
        model.addAttribute("futbol", futbol);

        model.addAttribute("comentarios", servicioComentarios.findByTutorial(futbol));
        model.addAttribute("nuevoComentario", new Comentario());

        return "futbolTutorial";
    }

    @PostMapping("/comentario/add")
    public String guardarComentario(@ModelAttribute("nuevoComentario") Comentario comentario, @RequestParam long idTutorial){
        comentario.setFecha(LocalDate.now());
        Futbol futbol=servicioFutbol.findById(idTutorial);
        comentario.setTutorial(futbol);
        servicioComentarios.save(comentario);
        return "redirect:/futbol/" + comentario.getTutorial().getId();
    }
    @GetMapping("/destinatario")
    public String destinatario(Model model) {
        //Recupero la lista de usuarios y la mando a la plantilla para decir quién soy
        model.addAttribute("lista", servicioUsuarios.findAll());
        return "destinatario";
    }

    @GetMapping("/chat/{id}")
    public String chat(@PathVariable long id, Model model, HttpSession request, Authentication authentication) {

        User actual = servicioUsuarios.findByEmail(authentication.getName());
        User destinatario = servicioUsuarios.findById(id);
        model.addAttribute("actual", actual);
        model.addAttribute("receptor", destinatario);

        //Debo enviar a la vista la lista de mensajes de "actual" a "destinatario" y viceversa
        List<Mensaje> lista1 = servicioMensajes.findByEmisorAndDestinatario(actual, destinatario);
        List<Mensaje> lista2 = servicioMensajes.findByEmisorAndDestinatario(destinatario, actual);

        //Mezclo las dos listas en una y la ordeno por fecha
        List<Mensaje> mezcla = new ArrayList<>();
        mezcla.addAll(lista1);
        mezcla.addAll(lista2);
        Collections.sort(mezcla, new Comparator<Mensaje>() {
            @Override
            public int compare(Mensaje m1, Mensaje m2) {
                return m1.getFecha().compareTo(m2.getFecha());
            }
        });
        model.addAttribute("listaMensajes", mezcla);

        //Envío un mensaje vacío que es el que después nos devolverá en PostMapping si escriben uno
        Mensaje mensaje = new Mensaje();
        mensaje.setEmisor(actual);
        mensaje.setDestinatario(destinatario);
        model.addAttribute("mensaje", new Mensaje());
        return "chat";
    }

    @PostMapping("/enviar")
    public String guardarMensaje(@ModelAttribute("mensaje") Mensaje mensaje,
                                 HttpServletRequest request, //Esto es para volver a la página desde la que nos han "llamado"
                                 @RequestParam("emisor") Long emisorid, //Es el id de quien envía el mensaje
                                 @RequestParam("destinatario") Long destinatarioid) // Es el id de quien recibe el mensaje
    {
        mensaje.setFecha(LocalDateTime.now());
        mensaje.setEmisor(servicioUsuarios.findById(emisorid));
        mensaje.setDestinatario(servicioUsuarios.findById(destinatarioid));
        servicioMensajes.save(mensaje);
        String referer = request.getHeader("Referer");
        return "redirect:" + referer;
    }

    @GetMapping("/preguntados")
    public String mostrarPreguntas(Model model) {
        List<Preguntas> preguntasAleatorias = servicioPreguntas.findRandomPreguntas(10);
        model.addAttribute("preguntasAleatorias", preguntasAleatorias);
        return "preguntados";
    }

    @PostMapping("/submit")
    public String submitQuiz(@RequestParam Map<String, String> respuestaMap, Model model, Authentication authentication) {
        int score = 0;
        User user = null;

        String username = authentication.getName();
        if (username != null) {
            user = servicioUsuarios.findByEmail(username);
        }

        if (user != null) {
            ResultadosTest resultadosTest = new ResultadosTest();
            resultadosTest.setUser(user);

            for (Map.Entry<String, String> entry : respuestaMap.entrySet()) {
                String preguntaId = entry.getKey();
                String respuestaUsuario = entry.getValue();

                if (preguntaId.startsWith("respuesta_")) {
                    Long id = Long.parseLong(preguntaId.replace("respuesta_", ""));

                    Preguntas pregunta = servicioPreguntas.findById(id);

                    if (pregunta != null && respuestaUsuario.equals(pregunta.getRespuestaCorrecta())) {
                        score++;
                    }
                }
            }

            resultadosTest.setScore(score);
            servicioResultadosTest.save(resultadosTest);
        }

        model.addAttribute("score", score);
        return "resultados";
    }

    @GetMapping("/userPerfil")
    public String miPerfil(Authentication authentication, Model model) {
        String username = authentication.getName();
        model.addAttribute("username", username);

        User user = servicioUsuarios.findByEmail(username);
        model.addAttribute("user", user);

        List<ResultadosTest> resultados = servicioResultadosTest.findByUser(user);
        model.addAttribute("resultados", resultados);

        return "perfil";
    }


}

