package com.example.registrationlogindemo.controller;

import com.example.registrationlogindemo.modelo.Futbol;
import com.example.registrationlogindemo.service.ServicioComentarios;
import com.example.registrationlogindemo.service.ServicioFutbol;
import com.example.registrationlogindemo.storage.StorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;

@Controller
public class Crud {
    @Autowired
    ServicioFutbol servicioFutbol;
    @Autowired
    ServicioComentarios servicioComentarios;

    @Autowired
    public StorageService storageService;

    //Este endpoint/url nos muestra la lista con todas las películas
    @GetMapping("/crud")
    public String listadoTutoriales(Model model){
        model.addAttribute("futbol", servicioFutbol.findAll());
        return "crud";
    }
    //Muestra el formulario para añadir películas, AÚN NO LA AÑADE
    @GetMapping("/crud/add")
    public String addTutorial(Model model){
        //formPelicula es el objeto que voy a usar en la plantilla
        model.addAttribute("formFutbol", new Futbol());
        return "form_add";
    }
    //Esta es la URL que aparece en el th:action del formulario para añadir películas
    //Lo que aparece en el ModelAttribute es lo mismo del th:object del formulario
    @PostMapping("/crud/save")
    public String guardarTutorial(@ModelAttribute("formFutbol") Futbol nuevoFutbol,
                                  @RequestParam("file") MultipartFile file){

        if (!file.isEmpty()) {
            String imagen = storageService.store(file, nuevoFutbol.getTitulo());
            System.out.println("La imagen a guardar es : " + imagen);
            //nuevaPelicula.setImagen(imagen);
            nuevoFutbol.setImagen(MvcUriComponentsBuilder
                    .fromMethodName(FileUploadController.class, "serveFile", imagen).build().toUriString());
        }

        servicioFutbol.save(nuevoFutbol);
        return "redirect:/crud/add";
    }

    @GetMapping("/crud/update/{id}")
    public String muestraTutorial(@PathVariable long id, Model model){
        Futbol futbol= servicioFutbol.findById(id);
        //El nombre del objeto debe ser el mismo que en el GetMapping de añadir
        //Y el mismo que en el th:object del formulario
        model.addAttribute("formFutbol", futbol);
        return "form_add";
    }

    @PostMapping("/crud/modificar")
    public String modificarTutorial(@ModelAttribute("formFutbol") Futbol futbol,
                                    @RequestParam("file") MultipartFile file){

        if (!file.isEmpty()) {
            String imagen = storageService.store(file, futbol.getTitulo());
            System.out.println("La imagen a guardar es : " + imagen);
            futbol.setImagen(MvcUriComponentsBuilder
                    .fromMethodName(FileUploadController.class, "serveFile", imagen).build().toUriString());
        }
        servicioFutbol.save(futbol);
        return "redirect:/crud";
    }

    @GetMapping("/crud/delete/{id}")
    public String borrarTutorial(@PathVariable long id, Model model){

        servicioFutbol.deleteById(id);
        return "redirect:/crud";
    }

}
