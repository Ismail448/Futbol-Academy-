package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.modelo.Comentario;
import com.example.registrationlogindemo.modelo.Futbol;
import com.example.registrationlogindemo.repository.RepositorioComentario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class ServicioComentarios {
    @Autowired
    RepositorioComentario repositorioComentario;

    public ArrayList<Comentario> findAll(){
        return repositorioComentario.findAll();
    }

    public Comentario findById(long id){
        return repositorioComentario.findById(id);
    }

    public ArrayList<Comentario> findByTutorial(Futbol futbol){
        return repositorioComentario.findByTutorial(futbol);
    }

    public Comentario save(Comentario comentario){
        return repositorioComentario.save(comentario);
    }

    public void delete(Comentario comentario){
        repositorioComentario.delete(comentario);
    }

}
