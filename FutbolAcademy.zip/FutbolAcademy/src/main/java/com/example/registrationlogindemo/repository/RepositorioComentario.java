package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.modelo.Comentario;
import com.example.registrationlogindemo.modelo.Futbol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface RepositorioComentario extends JpaRepository<Comentario, Long> {
    public ArrayList<Comentario> findAll();

    public Comentario findById(long id);

    public ArrayList<Comentario> findByTutorial(Futbol futbol);
    public Comentario save(Comentario comentario);

}