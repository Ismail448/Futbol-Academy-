package com.example.registrationlogindemo.repository;


import com.example.registrationlogindemo.modelo.Futbol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface RepositorioFutbol extends JpaRepository<Futbol, Long> {
    public ArrayList<Futbol> findAll();
    public Futbol findById(long id);
    public Futbol save(Futbol futbol);

    public ArrayList<Futbol> findByTitulo(String titulo);
}
