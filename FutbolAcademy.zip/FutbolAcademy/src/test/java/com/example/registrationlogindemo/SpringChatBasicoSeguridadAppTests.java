package com.example.registrationlogindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringChatBasicoSeguridadAppTests {

	@Test
	void contextLoads() {
	}

}
